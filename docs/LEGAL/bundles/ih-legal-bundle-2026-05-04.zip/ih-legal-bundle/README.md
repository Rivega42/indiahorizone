# IndiaHorizone Legal Bundle — для юр. консультации

> Собрано: 2026-05-04
> Источник: https://github.com/Rivega42/indiahorizone (ветка `docs/lawyer-questions`).
> Назначение: дать юристу или AI-юристу полный пакет документов перед
> консультацией по запуску компании.

## Структура

```
.
├── CLAUDE.md                          — общая концепция продукта
└── docs/
    ├── BUSINESS_MODEL.md              — что продаём / граница ответственности
    ├── BUSINESS_MODEL/
    │   └── UNIT_ECONOMICS.md
    ├── FINANCE/
    │   ├── CONTRACT_INTERCO.md        — inter-co РФ ↔ IN
    │   ├── REFUNDS.md
    │   └── PAYMENTS/
    │       ├── SCHEME.md              — схема денег end-to-end
    │       ├── CURRENCY_CONTROL.md    — 173-ФЗ
    │       └── AML.md                 — 115-ФЗ
    ├── LEGAL/
    │   ├── LAWYER_QUESTIONS.md        ⭐ основной документ — 73 вопроса
    │   ├── AI_LAWYER_PROMPT.md        ⭐ промпт для AI-юриста (Claude Projects)
    │   ├── TOUR_OPERATOR.md           — 132-ФЗ статус
    │   ├── PDN.md                     — карта ПДн (внутренний)
    │   ├── PRIVACY.md                 — публичная политика (черновик)
    │   ├── CONSENT.md                 — рамочное согласие
    │   ├── CONSENTS/
    │   │   ├── PDN.md
    │   │   ├── PHOTO_VIDEO.md         — granular consent (4 уровня)
    │   │   ├── GEO.md                 — granular consent (4 уровня)
    │   │   └── EMERGENCY_CONTACTS.md
    │   └── CONTRACTS/
    │       ├── CLIENT_OFFER.md        — каркас оферты
    │       └── GUIDE_CONTRACT.md      — каркас договора с гидом
    └── SOS/
        ├── CONCEPT.md                 — обещание SOS клиенту
        └── REGULATION.md              — SLA реакции
```

## С чего начать

1. Открыть [`docs/LEGAL/LAWYER_QUESTIONS.md`](docs/LEGAL/LAWYER_QUESTIONS.md)
   — это главный документ для встречи. 73 вопроса, разбитые на 8 блоков
   по приоритету (🔴 блокеры запуска / 🟡 важные / 🟢 на потом).
2. Для каждого вопроса в `LAWYER_QUESTIONS.md` указаны исходные документы
   в скобках — открывать по ходу.
3. [`docs/LEGAL/AI_LAWYER_PROMPT.md`](docs/LEGAL/AI_LAWYER_PROMPT.md) —
   готовый сетап для запуска AI-юриста в Claude Projects (custom
   instructions + промпт + список knowledge files).

## Статус документов

Все файлы помечены `status: draft` — они НЕ являются финальными
документами. Это рабочие черновики, которые ждут утверждения юриста.
Ваша задача и есть утвердить / переписать / отклонить.

## Контакт

Roman — @Rivega42 (Telegram, GitHub).
