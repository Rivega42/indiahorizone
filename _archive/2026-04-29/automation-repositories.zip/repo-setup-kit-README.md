# 📦 Repo Setup Kit

Комплект для одношаговой настройки любого репозитория через Claude Code.

## Что внутри

| Файл | Что делает |
|---|---|
| `REPO_SETUP_PROMPT.md` | главный промпт — кладёшь в репо и скармливаешь Claude Code |
| `scripts/setup-labels.sh` | создаёт 30+ лейблов |
| `scripts/setup-project.sh` | создаёт GitHub Project v2 со всеми кастомными полями |
| `scripts/dashboard-fetch.mjs` | собирает снепшот данных из GitHub GraphQL для дашборда |
| `scripts/automation/auto-labels.mjs` | синхронизация лейблов и Project Status |
| `scripts/automation/rollup.mjs` | каскадный прогресс эпиков по sub-issues |
| `scripts/automation/epic-sync.mjs` | синхронизация эпиков с Project и ROADMAP.md |
| `scripts/automation/deps.mjs` | резолв зависимостей "Зависит от: #N" |
| `scripts/automation/validate.mjs` | валидация обязательных полей в issue |
| `scripts/automation/digest.mjs` | еженедельный отчёт |
| `scripts/automation/notify.mjs` | Telegram уведомления |
| `scripts/automation/lib/graphql.mjs` | библиотека GraphQL-запросов |
| `scripts/automation/lib/parse.mjs` | парсинг body issues |
| `.github/workflows/*.yml` | 14 готовых workflow-ов |
| `.github/ISSUE_TEMPLATE/*.yml` | 6 YAML-форм для issues |
| `.github/PULL_REQUEST_TEMPLATE.md` | шаблон PR |
| `.github/dependabot.yml` | автообновление зависимостей |
| `.github/labeler.yml` | автолейблы по путям файлов |
| `.github/markdown-link-check.json` | конфиг проверки ссылок |
| `docs/ai/AUTOMATION.md` | полная документация автоматизации |

## Как использовать

### 1. Положи весь комплект в корень целевого репозитория

```bash
# Скопируй содержимое repo-setup-kit/ в корень своего репо
cp -r repo-setup-kit/* /path/to/your-repo/
cp -r repo-setup-kit/.github /path/to/your-repo/
cd /path/to/your-repo
```

### 2. Сделай скрипты исполняемыми

```bash
chmod +x scripts/setup-labels.sh scripts/setup-project.sh
```

### 3. Открой Claude Code в корне репо и скажи

```
Прочитай REPO_SETUP_PROMPT.md и начни выполнение с ШАГА 1.
```

Или если хочешь конкретный шаг:
```
Прочитай REPO_SETUP_PROMPT.md и выполни ШАГ 6 (лейблы и шаблоны).
```

### 4. Что Claude Code сделает сам
- Создаст AUDIT.md, README.md, CLAUDE.md, STATE.md, DECISIONS.md, ROADMAP.md, BACKLOG.md
- Расставит файлы комплекта по правильным путям в репо
- Адаптирует команды CI под стек проекта (Node/Python/Go/...)
- Создаст docs/ai/, docs/context/, docs/prompts/
- Сделает PR в main с описанием по шагам

### 5. Что Claude Code оформит как issues для Вики
- Создание GitHub Project v2 (через `scripts/setup-project.sh`)
- Применение лейблов (через `scripts/setup-labels.sh`)
- Branch protection
- GitHub Environments (staging, production)
- GitHub Pages для дашборда
- Включение Security Features
- Выдачу `PROJECT_TOKEN` PAT

### 6. Что Claude Code спросит у founders
- Лицензия проекта
- Стратегия веток (trunk-based / git-flow)
- Список запретных зон
- Telegram chat_id для уведомлений
- URLs staging/prod окружений

## Под капотом

```
┌───────────────────────────────────────────────────────────┐
│  GitHub events (issues, PR, schedule)                     │
└─────────────────────────┬─────────────────────────────────┘
                          │
                          ▼
┌───────────────────────────────────────────────────────────┐
│  .github/workflows/*.yml (14 workflow-ов)                 │
└─────────────────────────┬─────────────────────────────────┘
                          │ actions/github-script@v7
                          ▼
┌───────────────────────────────────────────────────────────┐
│  scripts/automation/*.mjs (ESM модули)                    │
│  ├── auto-labels.mjs     синк Status и лейблов            │
│  ├── rollup.mjs          прогресс эпиков                  │
│  ├── epic-sync.mjs       Project Epic + ROADMAP.md        │
│  ├── deps.mjs            зависимости #140 → #150          │
│  ├── validate.mjs        обязательные поля                │
│  ├── digest.mjs          еженедельный отчёт               │
│  ├── notify.mjs          Telegram                         │
│  └── lib/                                                 │
│      ├── graphql.mjs     GitHub GraphQL + Sub-issues API  │
│      └── parse.mjs       парсинг body issues              │
└─────────────────────────┬─────────────────────────────────┘
                          │
                          ▼
┌───────────────────────────────────────────────────────────┐
│  GitHub Project v2 (источник правды)                      │
│  + Labels (теги для совместимости)                        │
│  + Sub-issues API (иерархия)                              │
│  + Milestones (батчи/релизы)                              │
└─────────────────────────┬─────────────────────────────────┘
                          │ scripts/dashboard-fetch.mjs (1/час)
                          ▼
┌───────────────────────────────────────────────────────────┐
│  tools/dashboard/data/snapshot.json                       │
└─────────────────────────┬─────────────────────────────────┘
                          │ build + deploy
                          ▼
┌───────────────────────────────────────────────────────────┐
│  GitHub Pages — Roadmap, Backlog, Board, Deps             │
└───────────────────────────────────────────────────────────┘
```

## Под несколько проектов 1INT

Этот комплект — кандидат на твой `1int/repo-template`. Один раз настроил —
клонируешь при создании каждого нового проекта (EMDR42, Rescrub, Somazone,
VK Dating, библиотека) и Claude Code за час доводит репо до production-ready
состояния.

## Лицензия

MIT — используй как угодно.
